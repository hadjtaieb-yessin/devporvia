import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageHeaderComponent } from './components/page-header/page-header.component';
import { PageFooterComponent } from './components/page-footer/page-footer.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { MaterialModule } from './material.module';



@NgModule({
  declarations: [
    PageHeaderComponent,
    PageFooterComponent,
    SidebarComponent
  ],
  imports: [
    CommonModule,
    TranslateModule,
    RouterModule,
    MaterialModule
  ],
  exports: [
    PageHeaderComponent,
    PageFooterComponent,
    SidebarComponent,
    TranslateModule,
    MaterialModule
  ]
})
export class SharedModule { }
