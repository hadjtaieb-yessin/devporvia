import { Component } from '@angular/core';

@Component({
  selector: 'app-page-footer',
  standalone: false,
  templateUrl: './page-footer.component.html',
  styleUrl: './page-footer.component.scss'
})
export class PageFooterComponent {

}
