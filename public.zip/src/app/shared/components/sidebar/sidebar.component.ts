import { Component, inject } from '@angular/core';
import { LanguageService } from '../../../core/services/language.service';

@Component({
  selector: 'app-sidebar',
  standalone: false,
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent {
  showSidebar = false;

  private languageService = inject(LanguageService);


  menuItems = [
    { icon: '👤', route: '/user', label: 'SIDEBAR.USER' },
    { icon: '📚', route: '/management/program-management', label: 'SIDEBAR.PROGRAM' },
    { icon: '🗂️', route: '/management/project-management', label: 'SIDEBAR.PROJECT' },
    { icon: '🎓', route: '/management/certificate-management', label: 'SIDEBAR.CERTIFICATE' },
    { icon: '🏢', route: '/management/certificate-provider', label: 'SIDEBAR.CERTIFICATE_PROVIDER' },
    { icon: '▶️', route: '/management/program-execution', label: 'SIDEBAR.TRAINING_PROGRAM_EXECUTION' },
    { icon: '📝', route: '/management/training-request', label: 'SIDEBAR.TRAINING_REQUEST' },
  ];


}
