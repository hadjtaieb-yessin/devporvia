import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { LanguageService } from '../../../core/services/language.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-page-header',
  standalone: false,
  templateUrl: './page-header.component.html',
  styleUrl: './page-header.component.scss'
})
export class PageHeaderComponent implements OnInit, OnDestroy {
  isMenuOpen = false;
  isLangMenuOpen = false;
  isProfileMenuOpen = false;
  private langSubscription: Subscription;

  languages = [
    { code: 'en', name: 'English', direction: 'ltr' },
    { code: 'ar', name: 'العربية', direction: 'rtl' }
  ];
  currentLang = 'en';

  private languageService = inject(LanguageService);
  constructor() {
    this.currentLang = this.languageService.getCurrentLanguage();
  }

  ngOnInit() {
    console.log('PageHeaderComponent initialized');
    console.log('Current language from service:', this.languageService.getCurrentLanguage());

    this.langSubscription = this.languageService.currentLang$.subscribe(
      lang => {
        console.log('Language changed in subscription:', lang);
        this.currentLang = lang;
        console.log(`Current language: ${lang}, Direction: ${this.languageService.getDirection()}`);
      },
      error => {
        console.error('Error in language subscription:', error);
      }
    );
  }

  toggleProfileMenu() {
    this.isProfileMenuOpen = !this.isProfileMenuOpen;
  }
  toggleLangMenu() {
    this.isLangMenuOpen = !this.isLangMenuOpen;
  }

  ngOnDestroy() {
    if (this.langSubscription) {
      this.langSubscription.unsubscribe();
    }
  }

  changeLanguage(langCode: string) {
    console.log(`Attempting to change language to: ${langCode}`);
    this.isLangMenuOpen = false;
    try {
      const validLang = this.languages.find(lang => lang.code === langCode);
      if (!validLang) {
        console.error(`Invalid language code: ${langCode}`);
        return;
      }

      console.log(`Changing to valid language: ${validLang.name} (${validLang.direction})`);

      this.languageService.setLanguage(langCode);

      setTimeout(() => {
        const newLang = this.languageService.getCurrentLanguage();
        const newDirection = this.languageService.getDirection();
        console.log(`Language change verification - New lang: ${newLang}, New direction: ${newDirection}`);

        if (newLang !== langCode) {
          console.error(`Language change failed. Expected: ${langCode}, Got: ${newLang}`);
        }
      }, 100);
      this.isProfileMenuOpen = false;
    } catch (error) {
      console.error('Error changing language:', error);
    }
  }

  logout() {
    // Implement logout functionality
    this.isProfileMenuOpen = false;
    console.log('Logout clicked');
  }


}