import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiUrl = 'https://api.example.com/auth'; // À modifier avec l'URL de ton API

  constructor(private http: HttpClient) {}

  signup(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/signup`, data); // À modifier si nécessaire
  }

  signupInvite(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/signup-invite`, data); // À modifier si nécessaire
  }
}