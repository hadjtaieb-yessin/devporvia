import { inject, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LanguageService {
 private translate = inject(TranslateService);
  private currentLang = new BehaviorSubject<string>('en');
  private rtlLanguages = ['ar', 'he', 'fa'];
  
  currentLang$ = this.currentLang.asObservable();

  constructor() {
    // Configure the translation service
    this.translate.setDefaultLang('en');
    
    // Initialize language from localStorage or use default
    const savedLang = localStorage.getItem('preferred-language') || 'en';
    this.initializeLanguage(savedLang);
  }

  private initializeLanguage(lang: string) {
    // Avoid calling setLanguage in the constructor
    this.currentLang.next(lang);
    this.translate.use(lang);
    
    // Apply direction without saving
    this.applyDirection(lang);
  }

  private applyDirection(lang: string) {
    const direction = this.rtlLanguages.includes(lang) ? 'rtl' : 'ltr';
    
    // Update HTML attributes
    document.documentElement.dir = direction;
    document.documentElement.lang = lang;
    
    // Update CSS classes
    document.body.classList.remove('rtl', 'ltr');
    document.body.classList.add(direction);
    
    // Update body class
    document.body.className = direction;
  }

  setLanguage(lang: string) {
    console.log(`Setting language to: ${lang}`);
    
    // Update BehaviorSubject
    this.currentLang.next(lang);
    
    // Update translation service
    this.translate.use(lang);
    
    // Save preference
    localStorage.setItem('preferred-language', lang);
    
    // Apply direction
    this.applyDirection(lang);
    
    console.log(`Language set successfully. Direction: ${this.getDirection()}`);
  }

  getCurrentLanguage(): string {
    return this.currentLang.value;
  }

  isRTL(): boolean {
    return this.rtlLanguages.includes(this.currentLang.value);
  }

  getDirection(): string {
    return this.isRTL() ? 'rtl' : 'ltr';
  }

  // Method to reset language to default
  resetLanguage() {
    const defaultLang = 'en';
    this.setLanguage(defaultLang);
  }
}
