import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private defaultTheme: Record<string, string> = {
    'primary-color': '#1c1b1bff',
    'primary-text-color': '#090909ff',
    'header-bg': '#fff',
    'header-text-color': '#ffffff',
    'sidebar-bg': '#fff',
    'sidebar-text-color': '#333333',
    'sidebar-active-color': '#1976d2',
    'button-bg': '#ffffff',
    'button-text-color': '#000000ff',
    'hover-bg': '#eef3ff',
    'danger-color': '#d32f2f',
    'font-family': 'GE-Dinar-One',
    'primary-container-bg': '#fff',
    'body-bg': '#f1f5f9',
    'title-color': '#f57c00',
    'item-border-color': '#eeeeee'
  };

  setVariable(name: string, value: string) {
    document.documentElement.style.setProperty(name, value);
  }

  applyTheme(theme?: Record<string, string>) {
    const appliedTheme = { ...this.defaultTheme, ...(theme || {}) };
    Object.keys(appliedTheme).forEach(key => {
      this.setVariable(`--${key}`, appliedTheme[key]);
    });
  }
}