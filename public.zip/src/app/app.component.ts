import { Component, inject, OnInit } from '@angular/core';
import { ThemeService } from './core/services/theme.service';
import { LanguageService } from './core/services/language.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  title = 'provia-frontend';

  private theme = inject(ThemeService);
  public languageService = inject(LanguageService);

  ngOnInit() {
    // Simulate fetching from DB (null if not found)
    const themeFromDb: Record<string, string> | null = null;

    this.theme.applyTheme(themeFromDb ?? undefined);
  }

  // Expose a safe template-friendly API
  public isRTL(): boolean {
    return this.languageService.isRTL();
  }
}
