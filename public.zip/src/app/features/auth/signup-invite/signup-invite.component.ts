import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-signup-invite',
  standalone: false,
  templateUrl: './signup-invite.component.html',
  styleUrl: './signup-invite.component.scss'
})
export class SignupInviteComponent {

  signupForm!: FormGroup;
  showPassword = false;
  showConfirmPassword = false;
  isLoading = false;
  emailInvited = 'example@email.com'; // This should be dynamically set based on the invitation link

  countryCodes = [
    { code: '+966', label: 'Saudi Arabia' },
    { code: '+216', label: 'Tunisia' },
    { code: '+33', label: 'France' },
    { code: '+44', label: 'UK' }

  ];

  constructor(private formBuilder: FormBuilder, private authService: AuthService) {}

  ngOnInit(): void {
    this.initializeForm();
  }

  private initializeForm(): void {
    this.signupForm = this.formBuilder.group({
      fullName: ['', [Validators.required, Validators.minLength(2)]],
      countryCode: ['+966', Validators.required],
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{8,15}$/)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
      agreeToTerms: [false, Validators.requiredTrue]
    }, {
      validators: this.passwordMatchValidator
    });
  }

  private passwordMatchValidator(control: AbstractControl): { [key: string]: any } | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');

    if (!password || !confirmPassword) {
      return null;
    }

    return password.value !== confirmPassword.value ? { passwordMismatch: true } : null;
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.signupForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  hasPasswordMismatch(): boolean {
    const form = this.signupForm;
    return !!(form && form.errors?.['passwordMismatch'] && 
             form.get('confirmPassword')?.touched);
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }


  toggleConfirmPasswordVisibility(): void {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

getConfirmPasswordErrors(): string {
  const errors = [];
  const confirm = this.signupForm.get('confirmPassword');

  if (confirm?.hasError('required') && (confirm.dirty || confirm.touched)) {
    errors.push('تأكيد كلمة المرور مطلوب');
  }

  if (this.signupForm.errors?.['passwordMismatch'] && (confirm?.dirty || confirm?.touched)) {
    errors.push('كلمة المرور غير متطابقة');
  }

  return errors.join(' + '); 
}


  onSubmit(): void {
    if (this.signupForm.valid) {
      this.isLoading = true;
      
      const formData = {
        fullName: this.signupForm.value.fullName,
        phone: `${this.signupForm.value.countryCode}${this.signupForm.value.phone}`,
        password: this.signupForm.value.password,
        email: this.emailInvited //force the invited email in the payload
      };

       this.authService.signupInvite(formData)
      .pipe(finalize(() => this.isLoading = false))
      .subscribe({
        next: res => console.log('signup via invitation success', res),
        error: err => console.error('signup via invitation error', err)
      });

      /* console.log('show me the data form ==>:', formData);

     
      setTimeout(() => {
        this.isLoading = false;
        alert('تم إنشاء الحساب بنجاح!');

      }, 2000); */

    } else {
      this.markAllFieldsAsTouched();
    }
  }


  private markAllFieldsAsTouched(): void {
    Object.keys(this.signupForm.controls).forEach(key => {
      const control = this.signupForm.get(key);
      control?.markAsTouched();
    });
  }

}