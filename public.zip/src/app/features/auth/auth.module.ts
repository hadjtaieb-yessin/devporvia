import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';
import { AuthComponent } from './auth.component';
import { SignupComponent } from './signup/signup.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { CompleteDetailsComponent } from './complete-details/complete-details.component';
import { SignupInviteComponent } from './signup-invite/signup-invite.component';


@NgModule({
  declarations: [
    AuthComponent,
    SignupComponent,
    SignupInviteComponent,
    CompleteDetailsComponent
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    ReactiveFormsModule,
    RouterModule,
    SharedModule
  ]
})
export class AuthModule { }
