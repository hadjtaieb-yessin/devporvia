import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';

export function fullNameARValidator(control: AbstractControl): ValidationErrors | null {
  if (!control.value) return null;

  const words: string[] = control.value.trim().split(/\s+/);
  const arabicRegex = /^[\u0600-\u06FF]{2,}$/; 

  const validWords = words.filter((word: string) => arabicRegex.test(word));

  if (words.length < 4 || validWords.length !== words.length) {
    return { fullNameAR: true };
  }

  return null;
}

export function fullNameENValidator(control: AbstractControl): ValidationErrors | null {
  if (!control.value) return null;

  const words = control.value.trim().split(/\s+/);
  const englishRegex = /^[A-Za-z]{2,}$/;

  const validWords = words.filter((word: string) => englishRegex.test(word));

  if (words.length < 4 || validWords.length !== words.length) {
    return { fullNameEN: true };
  }

  return null;
}


@Component({
  selector: 'app-complete-details',
  standalone: false,
  templateUrl: './complete-details.component.html',
  styleUrl: './complete-details.component.scss'
})

export class CompleteDetailsComponent implements OnInit {

  profileForm!: FormGroup;
  description = ['السيد', 'الدكتور', 'المدير'];
  countries = ['Saudi Arabia', 'Tunisia', 'France', 'USA']; 
  city = ['Option 1', 'Option 2', 'Option 3'];
  region = ['Option A', 'Option B', 'Option C'];
  sector = ['Sector 1', 'Sector 2', 'Sector 3'];
  natureOfUser = ['User 1', 'User 2', 'User 3'];

   countryCodes = [
    { code: '+966', label: 'Saudi Arabia' },
    { code: '+216', label: 'Tunisia' },
    { code: '+33', label: 'France' },
    { code: '+44', label: 'UK' }

  ];

  invitedEmail = 'example@email.com';
  maxFileSize = 25 * 1024 * 1024; // 25MB
  

  constructor(private fb: FormBuilder) { }

ngOnInit(): void {
    this.profileForm = this.fb.group({
      Name: ['', [Validators.required, Validators.minLength(2), Validators.pattern(/^[\u0600-\u06FF\s]+$/)]],
      description: ['السيد', Validators.required],
      countryCode: ['+966', Validators.required], 
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{8,15}$/)]],
      email: ['', [Validators.required, Validators.email]],
      fullNameAR: ['', [Validators.required,fullNameARValidator]],
      fullNameEN: ['', [Validators.required,fullNameENValidator]],
      employmentNumber: [''],
      idNumber: [''],
      countries: ['', Validators.required],
      region: ['', Validators.required],
      city: ['', Validators.required],
      sector: ['Sector 1', Validators.required],
      natureOfUser:['User 1', Validators.required],
      file: [null]

    });
  }

   onSubmit(): void {
    if (this.profileForm.valid) {
      console.log('Formulaire envoyé', this.profileForm.value);
    } else {
      console.log('Formulaire invalide');
    }
  }

    isFieldInvalid(fieldName: string): boolean {
    const field = this.profileForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }


onFileSelectedOrDropped(file: File): void {
  if (!file) return;

  if (!file.type.startsWith('image/')) {
    alert('الصور فقط مسموح بها');
    return;
  }

  if (file.size > this.maxFileSize) {
    alert('الحجم الأقصى المسموح به هو 25 ميجا بايت');
    return;
  }

  this.profileForm.patchValue({ file: file });
  this.profileForm.get('file')?.updateValueAndValidity();
  console.log('File accepted :', file);
}

onFileSelected(event: Event): void {
  const input = event.target as HTMLInputElement;
  if (input.files && input.files.length > 0) {
    this.onFileSelectedOrDropped(input.files[0]);
  }
}

onFileDropped(event: DragEvent): void {
  event.preventDefault();
  if (event.dataTransfer && event.dataTransfer.files.length > 0) {
    this.onFileSelectedOrDropped(event.dataTransfer.files[0]);
  }
}

onDragOver(event: DragEvent): void {
  event.preventDefault();
}

onDragLeave(event: DragEvent): void {
  event.preventDefault();
}


getNameErrors(): string[] {
  const errors = this.profileForm.get('Name')?.errors;
  if (!errors) return [];

  const messages: string[] = [];
  if (errors['required']) messages.push('الإسم مطلوب');
  if (errors['minlength']) messages.push('الاسم يجب أن يكون مكونا من حرفين على الأقل');
  if (errors['pattern']) messages.push('الإسم يجب أن يكون مكونا من الحروف العربية فقط');

  return messages;
}

getPhoneErrors(): string[] {
  const errors = this.profileForm.get('phone')?.errors;
  if (!errors) return [];

  const messages: string[] = [];
  if (errors['required']) messages.push('رقم الهاتف مطلوب');
  if (errors['pattern']) messages.push('صيغة رقم الهاتف غير صحيحة')
  return messages;
}

getEmailErrors(): string[] {
  const errors = this.profileForm.get('email')?.errors;
  if (!errors) return [];

  const messages: string[] = [];
  if (errors['required']) messages.push('البريد الإلكتروني مطلوب');
  if (errors['email']) messages.push('صيغة البريد الإلكتروني غير صحيحة')
  return messages;
}


}