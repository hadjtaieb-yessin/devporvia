import { TestBed } from '@angular/core/testing';

import { TrainingApiService } from './training-api.service';

describe('TrainingApiService', () => {
  let service: TrainingApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TrainingApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
