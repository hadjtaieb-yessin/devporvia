import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TrainingRoutingModule } from './training-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { ProjectListComponent } from './pages/project/project-list/project-list.component';
import { ProjectFormComponent } from './pages/project/project-form/project-form.component';
import { ProgramFormComponent } from './pages/program/program-form/program-form.component';
import { ProgramListComponent } from './pages/program/program-list/program-list.component';
import { CertificateListComponent } from './pages/certificate/certificate-list/certificate-list.component';


@NgModule({
  declarations: [
    ProjectListComponent,
    ProjectFormComponent,
    ProgramFormComponent,
    ProgramListComponent,
    CertificateListComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    TrainingRoutingModule
  ]
})
export class TrainingModule { }
