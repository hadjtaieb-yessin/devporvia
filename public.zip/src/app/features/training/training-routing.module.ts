import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProjectListComponent } from './pages/project/project-list/project-list.component';
import { ProgramListComponent } from './pages/program/program-list/program-list.component';
import { CertificateListComponent } from './pages/certificate/certificate-list/certificate-list.component';

const routes: Routes = [
  { path: '', component: ProgramListComponent, data: { title: 'Program List' } },
  { path: 'program-management', component: ProgramListComponent, data: { title: 'Program List' } },
  { path: 'project-management', component: ProjectListComponent, data: { title: 'Project List' } },
  { path: 'certificate-management', component: CertificateListComponent, data: { title: 'Certificate List' } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TrainingRoutingModule { }
