import { Component } from '@angular/core';

@Component({
  selector: 'app-certificate-list',
  standalone: false,
  templateUrl: './certificate-list.component.html',
  styleUrl: './certificate-list.component.scss'
})
export class CertificateListComponent {

}
