import { Component } from '@angular/core';

@Component({
  selector: 'app-program-list',
  standalone: false,
  templateUrl: './program-list.component.html',
  styleUrl: './program-list.component.scss'
})
export class ProgramListComponent {

}
