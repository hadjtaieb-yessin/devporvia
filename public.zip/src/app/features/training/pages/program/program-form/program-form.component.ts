import { Component } from '@angular/core';

@Component({
  selector: 'app-program-form',
  standalone: false,
  templateUrl: './program-form.component.html',
  styleUrl: './program-form.component.scss'
})
export class ProgramFormComponent {

}
