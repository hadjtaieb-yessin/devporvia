import { Component, OnInit, inject } from '@angular/core';
import { LanguageService } from '../../../../../core/services/language.service';

interface User {
  name: string;
  email: string;
  role: string;
  organisation: string;
  status: 'Active' | 'InActive';
  photo: string;
}

@Component({
  selector: 'app-user-list',
  standalone: false,
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {
  currentLanguage = 'en';
  
  private languageService = inject(LanguageService);

  // pagination
  pageSize = 5;
  currentPage = 1;
  pagedData: User[] = [];
  totalPages = 0;
  totalPagesArray: number[] = [];
  dataSource: User[] = [];

  ngOnInit(): void {
    this.dataSource = [...this.users];
    this.totalPages = Math.ceil(this.dataSource.length / this.pageSize);
    this.updatePagedData();
    
    this.languageService.currentLang$.subscribe(lang => {
      this.currentLanguage = lang;
    });
  }
  
  isRTL(): boolean {
    return this.languageService.isRTL();
  }

  applyFilter(value: string) {
    const filterValue = value.trim().toLowerCase();
    this.dataSource = this.users.filter((u: User) =>
      u.name.toLowerCase().includes(filterValue) ||
      u.email.toLowerCase().includes(filterValue) ||
      u.role.toLowerCase().includes(filterValue) ||
      u.organisation.toLowerCase().includes(filterValue) ||
      u.status.toLowerCase().includes(filterValue)
    );
    this.currentPage = 1;
    this.totalPages = Math.ceil(this.dataSource.length / this.pageSize);
    this.updatePagedData();
  }

  updatePagedData() {
    this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);

    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.pagedData = this.dataSource.slice(start, end);
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updatePagedData();
    }
  }

  sortData(column: keyof User) {
    this.dataSource.sort((a: User, b: User) => {
      const av = String(a[column]).toLowerCase();
      const bv = String(b[column]).toLowerCase();
      if (av > bv) return 1;
      if (av < bv) return -1;
      return 0;
    });
    this.updatePagedData();
  }

  edit(row: User) {
    console.log("Edit:", row);
  }

  remove(row: User) {
    console.log("Remove:", row);
  }

  toggleStatus(row: User) {
    console.log("Toggle Status:", row);
  }

  columns = [
    { key: 'actions', label: 'ACTIONS' },
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    { key: 'role', label: 'Role' },
    { key: 'organisation', label: 'Organisation' },
    { key: 'status', label: 'Status' },
    { key: 'photo', label: 'Photo' }
  ];

  users: User[] = [
    {
      name: 'Ahmed Ben Ali',
      email: 'ahmed.benali@example.com',
      role: 'Admin',
      organisation: 'Provia',
      status: 'Active',
      photo: 'assets/media/avatars/blank.png'
    },
    {
      name: 'Sara Haddad',
      email: 'sara.haddad@example.com',
      role: 'Trainee',
      organisation: 'Provia Academy',
      status: 'Active',
      photo: 'assets/media/avatars/blank.png'
    },
    {
      name: 'Ali Mansour',
      email: 'ali.mansour@example.com',
      role: 'Manager',
      organisation: 'Provia',
      status: 'Active',
      photo: 'assets/media/avatars/blank.png'
    },
    {
      name: 'Nour Kamel',
      email: 'nour.kamel@example.com',
      role: 'User',
      organisation: 'Provia Partners',
      status: 'InActive',
      photo: 'assets/media/avatars/blank.png'
    },
    {
      name: 'Omar Saidi',
      email: 'omar.saidi@example.com',
      role: 'Admin',
      organisation: 'Provia',
      status: 'Active',
      photo: 'assets/media/avatars/blank.png'
    }
  ];
}
